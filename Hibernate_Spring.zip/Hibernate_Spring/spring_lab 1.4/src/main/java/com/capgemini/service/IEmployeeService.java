package com.capgemini.service;

import com.capg.entities.Employee;

public interface IEmployeeService {
    Employee fetchById(int id);

}
