package org.capgemini.dto;

public class CustomerDto {
	
	private String cust_Name;

	public String getcust_Name() {
		return cust_Name;
	}

	public void setcust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}
	
}
